DISCLAIMER:
This script is intended for EDUCATIONAL, FORENSIC RESEARCH, and AUTHORIZED PENETRATION TESTING ONLY.
The creator does not endorse or encourage any illegal or unethical activities. 

- **LEGAL COMPLIANCE**: Use only on systems you own or have explicit permission to test.
- **ETHICAL USE**: Do not deploy in unauthorized environments or for malicious purposes.
- **RESPONSIBILITY**: The user assumes all liability for misuse of this tool.

By running this script, you agree to use it lawfully and ethically.

website : https://hackoor.com
suport : support@hackoor.com
org. : 47cyber technology 